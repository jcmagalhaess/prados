=== WooCommerce.com Update Manager - A Plugin Built and Supported by Woo.com for Managing Extensions Purchased from Woo.com ===
Contributors: automattic
Tags: woo-update-manager
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 7.3
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

== Description ==

**Securely update WooCommerce extensions managed by Woo.com.**

== Getting Started ==

= Requirements =

* WordPress 6.0 or newer.
* WooCommerce 8.7 or newer.
* PHP 7.3 or newer is recommended.

== Installation ==

Download WooCommerce.com Update Manager plugin from https://woocommerce.com/product-download/woo-update-manager.
